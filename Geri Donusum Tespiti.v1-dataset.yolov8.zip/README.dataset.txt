# Geri Donusum Tespiti > dataset
https://universe.roboflow.com/okan-yksel/geri-donusum-tespiti

Provided by a Roboflow user
License: CC BY 4.0

